package modelo;

public class SQLQuerys {
	// SELECTS
	public static final String SELECT_TODOS_PAISES = "select * from Pais ";
	
	// INSERTS
	public static final String INSERT_PAIS = "insert into Pais values ('";
	public static final String SEPARATOR = "' , '";
	public static final String END_BLOCK = "' )";
	
	// DELETES 
	public static final String DELETE_PAISES = "delete from pais";

}
