package modelo;

public class DBUtils {
	public static final String URL = "jdbc:mysql://localhost:33060/paises";
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String USER = "root";
	public static final String PASS = "elorrieta";
}
