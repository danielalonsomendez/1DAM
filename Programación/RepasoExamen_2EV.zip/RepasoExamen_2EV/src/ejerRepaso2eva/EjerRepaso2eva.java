package ejerRepaso2eva;

import vista.Menu;

public class EjerRepaso2eva {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.verMenu();
	}

}
