module EjerBD {
	requires java.sql;
}